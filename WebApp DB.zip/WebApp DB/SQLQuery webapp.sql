
CREATE TABLE Users (
    UserID int primary key,
	FirstName varchar(255),
    LastName varchar(255),
    PhoneNumber int,
	Email varchar(255),
	Suburb varchar(255),
	Postcode int,
	PetName varchar(255),
	PetBreed varchar(255),
	PetAge varchar(255),
	PetGender Varchar(255),
	PetImage varchar(255),
	)
	select * from Users









/*The account creation process will require the following information to be entered by the account creator:

 

�         First name matt

 

�         Surname matt

 

�         Contact phone number 1800matt

 

�         Email address matt@matt.com    notabot@gmail.com

 

�         Suburb

 

�         Postcode

 

�         Pet name

 

�         Pet breed

 

�         Pet age

 

�         Pet gender

 

�         Photo (image) of pet

 