﻿using System;
using System.Collections.Generic;

namespace WebApp.Model.EF
{
    public partial class User
    {
        public int UserId { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public int? PhoneNumber { get; set; }
        public string? Email { get; set; }
        public string? Suburb { get; set; }
        public int? Postcode { get; set; }
        public string? PetName { get; set; }
        public string? PetBreed { get; set; }
        public string? PetAge { get; set; }
        public string? PetGender { get; set; }
        public string? PetImage { get; set; }
    }
}
