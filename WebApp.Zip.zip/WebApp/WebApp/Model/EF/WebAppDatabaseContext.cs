﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace WebApp.Model.EF
{
    public partial class WebAppDatabaseContext : DbContext
    {
        public WebAppDatabaseContext()
        {
        }

        public WebAppDatabaseContext(DbContextOptions<WebAppDatabaseContext> options)
            : base(options)
        {
        }

        public virtual DbSet<User> Users { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=DESKTOP-E3BO3KG\\MSSQLSERVER01;Database=WebApp Database;integrated security=true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>(entity =>
            {
                entity.Property(e => e.UserId)
                    .ValueGeneratedNever()
                    .HasColumnName("UserID");

                entity.Property(e => e.Email)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.FirstName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.PetAge)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.PetBreed)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.PetGender)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.PetImage)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.PetName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Suburb)
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
